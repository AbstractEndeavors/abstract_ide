
from .main import *
def startIdeConsole():
    startConsole(ideTab)
