from .main import testRunnerTab
from abstract_gui import startConsole
def startTestRunnerConsole():
    startConsole(testRunnerTab)
