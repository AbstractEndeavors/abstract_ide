from abstract_utilities.robust_readers import *
apply_inits(root=get_caller_dir(1))
from .main import *
def startIdeConsole():
    startConsole(ideTab)
