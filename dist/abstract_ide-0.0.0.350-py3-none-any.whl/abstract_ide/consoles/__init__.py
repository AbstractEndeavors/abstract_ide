from abstract_utilities.path_utils.req import *
get_for_all_tabs()
from .main import *
def startIdeConsole():
    startConsole(ideTab)
