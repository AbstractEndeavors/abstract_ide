from consoles import *
from abstract_gui import *
startConsole(launcherWindowTab)

